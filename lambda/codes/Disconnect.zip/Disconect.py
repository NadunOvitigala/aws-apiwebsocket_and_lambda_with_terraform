def lambda_handler(event, context):
    connection_id = event['requestContext']['connectionId']

    # Add your custom logic for handling disconnect events here

    return {
        'statusCode': 200,
        'body': 'Disconnected successfully.'
    }
