def lambda_handler(event, context):
    connection_id = event['requestContext']['connectionId']

    # Add your custom logic for handling connect events here

    return {
        'statusCode': 200,
        'body': 'Connected successfully.'
    }
